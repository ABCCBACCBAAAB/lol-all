# 套件引入
___ ___

# 讀取攝影機
cap = ___.VideoCapture(0)

# 讀取模型
face_cascade = cv2.CascadeClassifier(r"haarcascade_frontalface_default.xml")

# 判斷攝影機有無開啟
if not ___.isOpened():
    # 印出資訊
    ___("Cannot open camera")
    exit()

## 迴圈
___ True:
    
    # 讀取攝影機拍到的畫面
    ret, frame = ___.read()
    
    # 判斷
    __ not ret:
        print("Cannot receive frame")
        # 跳出迴圈
        _____
    
    # 將鏡頭影像轉換成灰階
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # 偵測人臉
    faces = face_cascade.detectMultiScale(gray)
    
    # 迴圈 標記人臉
    ___ (x, y, w, h) ___ faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
    
    # 顯示  
    cv2.imshow('oxxostudio', frame)
    
    # 按下鍵盤任意鍵結束
    if cv2.waitKey(1) != -1: 
        break

cap.release()
cv2.destroyAllWindows()